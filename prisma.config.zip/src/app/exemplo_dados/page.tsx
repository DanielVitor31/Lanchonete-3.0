import { prisma } from "@/lib/prisma";
import { Box } from "@mui/material";
import { supabaseStorageURL } from "@/ultils/ultils";


export default async function FoodsPage() {
  const foods = await prisma.foods.findMany({
    select: {
      id_food: true,
      name: true,
      price: true,
    },
    orderBy: {
      created_at: "desc",
    },
  });

  return (
    <div style={{ padding: 20 }}>
      <h1>Foods</h1>
      <ul>
        {foods.map((f) => (
          <li key={f.id_food}>
            {f.name} — R$ {f.price.toString()}
          </li>
        ))}
      </ul>
      <Box
        component="img"
        src={supabaseStorageURL("logos", "logo.webp")}
        alt="logo"
        sx={{ width: 120 }}
      />
    </div>
  );
}
