import { prisma } from "@/lib/prisma";

export default async function TesteFoods() {
  const foods = await prisma.foods.findMany({
    orderBy: { created_at: "desc" },
  });

  return (
    <div style={{ padding: 20 }}>
      <h1>Foods</h1>
      <pre>{JSON.stringify(foods, null, 2)}</pre>
    </div>
  );
}
