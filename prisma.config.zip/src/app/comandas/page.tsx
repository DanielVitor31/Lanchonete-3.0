"use client";

import { Typography } from "@mui/material";

export default function ComandasPage() {
  return (
    <>
      <Typography variant="h4" fontWeight={700} mb={2}>
        Comandas
      </Typography>
      <Typography variant="body1" color="text.secondary">
        Aqui depois vai a tela de comandas abertas, finalizadas, etc.
      </Typography>
    </>
  );
}
