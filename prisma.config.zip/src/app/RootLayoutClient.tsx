"use client";

import { ReactNode, useEffect, useMemo, useState } from "react";
import { ThemeProvider, CssBaseline, Box } from "@mui/material";
import {Header} from "@/components/Header";
import {Footer} from "@/components/Footer";
import { calcHours, applyCssVars } from "@/ultils/ultils"


type Props = {
  children: ReactNode;
  colorsDB: { name: string; value: string }[] | null;
};

export default function RootLayoutClient({children, colorsDB,}: Props) {

  // 2) CSS vars vindas do banco: --icon_dark, --fundo_light etc
  useEffect(() => {
    let colors
    let colorsLocalStorage = localStorage.getItem("colorsDB");
    const colorsLocalStorageTime = !!colorsLocalStorage ? JSON.parse(colorsLocalStorage)[0].timestamp : null
    const calcTime = calcHours(colorsLocalStorageTime, 12)

    if (!colorsLocalStorage || calcTime) {
      document.cookie = `colorsDB=1; path=/; max-age=31536000`;
      
      // const colorsDBFormat = {
      //   timestamp: new Date(),
      //   data: colorsDB
      // };

      // localStorage.setItem("colorsDB", JSON.stringify(colorsDBFormat));
      // colors = JSON.parse(localStorage.getItem("colorsDB")!)[0].data

      // applyCssVars(colors)
    } else {
      document.cookie = `colorsDB=; path=/; max-age=0`; // remove cookie
    }
  }, []);


  return (
    <Box >
      <CssBaseline />
      <Box sx={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
        <Header />
        <Box component="main" sx={{ flexGrow: 1, maxWidth: 1200, mx: "auto", p: 2 }}>
          {children}
        </Box>
        <Footer />
      </Box>
    </Box>
  );
}
