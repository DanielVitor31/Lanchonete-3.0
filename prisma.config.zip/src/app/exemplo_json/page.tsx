import { prisma } from "@/lib/prisma";

export default async function TesteFoods() {
  const food = await prisma.settings_colors.findMany({
  select: {
    name: true,
    value: true,
  }
});

  const resposta = {
  timestamp: new Date(), // aqui tá a data/hora atual
  data: food
};

  return (
    <div style={{ padding: 20 }}>
      <h1>Teste Prisma 7 + Supabase</h1>
      <pre>{JSON.stringify(resposta)}</pre>
    </div>
  );
}
