  export const ROUTES_STRING = [
    { label: "Início", href: "/" },
    { label: "Cardápio", href: "/cardapio" },
    { label: "Comandas", href: "/comandas" },
    { label: "Pedidos", href: "/pedidos" },
  ];