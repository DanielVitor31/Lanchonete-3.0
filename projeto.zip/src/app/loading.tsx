export default function Loading() {
  return (
    <p>Carregando dados do banco...</p>
  );
}
