import { prisma } from "@/lib/prisma";

export default async function TesteFoods() {


  return (
    <div className="max-w-xl space-y-4">
      <p className="text-sm font-medium text-zinc-200">Selecione uma opção:</p>

      <div className="space-y-3">
        <label className="block cursor-pointer">
          <input
            type="radio"
            name="tipoPlano"
            value="basic"
            className="peer sr-only"
          />
          <div
            className="flex items-start gap-3 rounded-2xl border border-zinc-700 bg-zinc-900/60 px-4 py-3
               shadow-sm transition
               hover:-translate-y-[1px] hover:border-emerald-400/70 hover:shadow-lg
               peer-checked:border-emerald-400 peer-checked:bg-emerald-500/10 peer-checked:shadow-xl"
          >
            <div
              className="mt-1 flex h-5 w-5 items-center justify-center rounded-full border border-zinc-500 bg-zinc-950
                 transition peer-checked:border-emerald-400"
            >
              <span
                className="h-2.5 w-2.5 rounded-full bg-emerald-400 opacity-0 transition
                   peer-checked:opacity-100 peer-checked:scale-100"
              ></span>
            </div>

            <div className="flex flex-col">
              <span className="text-sm font-semibold text-zinc-100">
                Básico
              </span>
              <span className="text-xs text-zinc-400">
                O suficiente pra testar as águas.
              </span>
            </div>

            <span
              className="ml-auto mt-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-emerald-300
                 peer-checked:bg-emerald-500/20"
            >
              Popular
            </span>
          </div>
        </label>

        <label className="block cursor-pointer">
          <input
            type="radio"
            name="tipoPlano"
            value="classNameic"
            className="peer sr-only"
          />
          <div
            className="flex items-start gap-3 rounded-2xl border border-zinc-700 bg-zinc-900/60 px-4 py-3
               shadow-sm transition
               hover:-translate-y-[1px] hover:border-sky-400/70 hover:shadow-lg
               peer-checked:border-sky-400 peer-checked:bg-sky-500/10 peer-checked:shadow-xl"
          >
            <div
              className="mt-1 flex h-5 w-5 items-center justify-center rounded-full border border-zinc-500 bg-zinc-950
                 transition peer-checked:border-sky-400"
            >
              <span
                className="h-2.5 w-2.5 rounded-full bg-sky-400 opacity-0 transition
                   peer-checked:opacity-100"
              ></span>
            </div>

            <div className="flex flex-col">
              <span className="text-sm font-semibold text-zinc-100">
                Clássico
              </span>
              <span className="text-xs text-zinc-400">
                Equilíbrio entre custo e recursos.
              </span>
            </div>
          </div>
        </label>

        <label className="block cursor-pointer">
          <input
            type="radio"
            name="tipoPlano"
            value="pro"
            className="peer sr-only"
          />
          <div
            className="flex items-start gap-3 rounded-2xl border border-zinc-700 bg-zinc-900/60 px-4 py-3
               shadow-sm transition
               hover:-translate-y-[1px] hover:border-violet-400/70 hover:shadow-lg
               peer-checked:border-violet-400 peer-checked:bg-violet-500/10 peer-checked:shadow-xl"
          >
            <div
              className="mt-1 flex h-5 w-5 items-center justify-center rounded-full border border-zinc-500 bg-zinc-950
                 transition peer-checked:border-violet-400"
            >
              <span
                className="h-2.5 w-2.5 rounded-full bg-violet-400 opacity-0 transition
                   peer-checked:opacity-100"
              ></span>
            </div>

            <div className="flex flex-col">
              <span className="text-sm font-semibold text-zinc-100">
                Pro
              </span>
              <span className="text-xs text-zinc-400">
                Pra quem leva o negócio a sério.
              </span>
            </div>

            <span
              className="ml-auto mt-1 rounded-full bg-violet-500/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-violet-300"
            >
              Recomendado
            </span>
          </div>
        </label>

        <label className="block cursor-pointer">
          <input
            type="radio"
            name="tipoPlano"
            value="family"
            className="peer sr-only"
          />
          <div
            className="flex items-start gap-3 rounded-2xl border border-zinc-700 bg-zinc-900/60 px-4 py-3
               shadow-sm transition
               hover:-translate-y-[1px] hover:border-amber-400/70 hover:shadow-lg
               peer-checked:border-amber-400 peer-checked:bg-amber-500/10 peer-checked:shadow-xl"
          >
            <div
              className="mt-1 flex h-5 w-5 items-center justify-center rounded-full border border-zinc-500 bg-zinc-950
                 transition peer-checked:border-amber-400"
            >
              <span
                className="h-2.5 w-2.5 rounded-full bg-amber-400 opacity-0 transition
                   peer-checked:opacity-100"
              ></span>
            </div>

            <div className="flex flex-col">
              <span className="text-sm font-semibold text-zinc-100">
                Família
              </span>
              <span className="text-xs text-zinc-400">
                Ideal pra alto volume e várias pessoas usando.
              </span>
            </div>
          </div>
        </label>

        <label className="block cursor-pointer">
          <input
            type="radio"
            name="tipoPlano"
            value="ultra"
            className="peer sr-only"
          />
          <div
            className="flex items-start gap-3 rounded-2xl border border-zinc-700 bg-gradient-to-r from-fuchsia-600/50 via-emerald-500/30 to-sky-500/40 px-4 py-3
               shadow-md transition
               hover:-translate-y-[2px] hover:shadow-xl
               peer-checked:shadow-[0_0_25px_rgba(244,114,182,0.6)]"
          >
            <div
              className="mt-1 flex h-5 w-5 items-center justify-center rounded-full border border-fuchsia-300/80 bg-zinc-950/80
                 shadow-[0_0_12px_rgba(244,114,182,0.7)]"
            >
              <span
                className="h-2.5 w-2.5 rounded-full bg-fuchsia-300"
              ></span>
            </div>

            <div className="flex flex-col">
              <span className="text-sm font-semibold text-white tracking-wide">
                Ultra
              </span>
              <span className="text-xs text-fuchsia-100/90">
                Modo ostentação: máximo recurso, máximo impacto visual.
              </span>
            </div>

            <span
              className="ml-auto mt-1 rounded-full bg-black/40 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-fuchsia-100"
            >
              Full Power
            </span>
          </div>
        </label>
      </div>
    </div>


  );
}
